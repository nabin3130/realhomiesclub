
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateIntroduction = async (profileName: string, bio: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a Creative Brand Strategist and Hype Man for the "real homies club". 
      Aesthetic: 70s retro, burnt orange/cream palette, authentic and supportive.
      Generate a short, energetic 2-sentence greeting for ${profileName.toLowerCase()}'s profile. 
      Base it on this bio: "${bio}". 
      RULES:
      1. Always refer to the club as "real homies club" in all lowercase.
      2. Keep the entire response in lowercase.
      3. No corporate jargon. Be authentic, witty, and grounded.`,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini failed to generate intro:", error);
    return `welcome to the real homies club. we're glad you're here. let's stay real.`;
  }
};

export const chatWithHomie = async (userMessage: string, context: string) => {
  try {
    const chat = ai.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: `You are the AI representative of the "real homies club". 
        Context about the club: ${context}. 
        Aesthetic: 70s retro vibe. Friendly, authentic, witty, and supportive.
        RULES:
        1. Always refer to the club as "real homies club" in all lowercase.
        2. Keep your entire response in lowercase.
        3. Avoid corporate jargon.
        4. Be brief and welcoming.`,
      }
    });
    const result = await chat.sendMessage({ message: userMessage });
    return result.text;
  } catch (error) {
    return "yo, i'm having a hard time hearing you. try again in a sec.";
  }
};
